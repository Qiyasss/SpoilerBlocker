package util;

public class SpoilerBlockerrUtil {

    public static void blocker() {

            String sNew = Opinion.opinion().replaceAll("die", "***");
            System.out.println(sNew);

            }
        }







